# Pruefbelege r4 (Disroop Motion One)

Rohbelege unveraendert aus dem Repo kopiert (Pfade relativ zu devices/motion-one/). Nichts neu erzeugt oder interpretiert.
Dateiexistenz ist kein PASS: Inhalte sind zu oeffnen und zu pruefen. Reale Hardware: NOT RUN.

| Datei | Zweck | Label |
|---|---|---|
| logs/pcb-r4c/erc.json, ui_erc.json, logs/pcb-r4d/erc.json | ERC Hauptboard / Control-Board | MESSUNG (kicad-cli) |
| logs/pcb-r4c/motion-one_drc_pin1.json, motion-one-ui_drc_pin1.json, ui_drc.json | DRC Hauptboard / Control-Board | MESSUNG (kicad-cli) |
| logs/pcb-r4/drc.json, erc.json, ui_drc.json, ui_erc.json | frueherer Stand r4 (Verlauf) | MESSUNG (kicad-cli) |
| electronics/spice/* (results.json, *.log, *.csv, *.cir) | SPICE: Powerpath, Inrush, VBAT-Teiler, Buzzer/Motor, Worst-Case 3.3/3.5 V | SIMULATION (ngspice) |
| logs/fw-pinmap/unit-tests.log | Firmware-Unit-Tests (Host) | MESSUNG (Testlauf) |
| logs/fw-pinmap/app-build.log, versions.txt, zephyr.sha256 | Firmware-Build-Log, Versionen, Hash | MESSUNG (Build) |
| logs/fw-r4/unit-tests.log, app-build.log, bootloader-build.log, versions.txt | Firmware r4 Test-/Build-Logs | MESSUNG (Testlauf/Build) |
| mechanics/cad/collision_r4.json | Kollisionspruefung Baugruppe r4 | BERECHNUNG (CAD) |
| logs/wall_min.json, wall_ray.json, wall_section.json | Wandstaerke am CAD-Modell | MESSUNG (CAD) |
| logs/stl_check_r4.json, logs/pcb-r4d/pcb_r4_stl_check.json | STL-Pruefung (wasserdicht, offene Kanten) | BERECHNUNG (trimesh) |
| management/metrics.json | Kennzahlen des Managers | gemischt, Labels in der Datei |

Hinweis: Eine separate Lippenspiel-Messdatei existiert im Repo nicht und ist darum nicht enthalten.
