#!/usr/bin/env python3
"""Explicit, audited namespace-only PCB migration for the selected hierarchy.

No tracks, pads, zones, footprints, UUIDs, dimensions or pin groups may change.
This script is intentionally separate from schematic generation.
"""
import copy
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from sexpr import parse,find,Q,dump
ROOT=HERE.parents[3]
E=ROOT/'devices/motion-one/electronics'
WORK=E/'exports/hierarchical_r4_work'
BASE=WORK/'baseline'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def pcb_name(name):
    # XML presents literal pin-name slashes; PCB/DRC use KiCad's escaped atom
    # for slashes within auto-generated pin names (not hierarchy separators).
    return name.replace('/','{slash}') if name.startswith(('Net-(','unconnected-(')) else name

def xml_data(path):
    xml=ET.parse(path)
    comps={c.get('ref'):(c.findtext('value'),c.findtext('footprint'))
           for c in xml.findall('.//components/comp') if not c.get('ref').startswith('#')}
    nets={frozenset((p.get('ref'),p.get('pin')) for p in n.findall('node') if not p.get('ref').startswith('#')):n.get('name')
          for n in xml.findall('.//nets/net')}
    net_comps={c.get('ref'):c for c in xml.findall('.//components/comp')}
    return comps,nets,net_comps

def board_semantics(tree,inverse):
    out=copy.deepcopy(tree)
    def visit(node):
        if not isinstance(node,list):return
        if node and node[0] in ['net','net_name'] and len(node)>1 and isinstance(node[-1],str):
            node[-1]=Q(inverse.get(str(node[-1]),str(node[-1])))
        if node and node[0]=='footprint':
            node[:]=[v for v in node if not(isinstance(v,list) and v[0] in ['path','sheetname','sheetfile'])]
        for value in node:visit(value)
    visit(out)
    return out

reports={}
for project in ['motion-one','motion-one-ui']:
    old_comps,old_nets,_=xml_data(BASE/(project+'.netlist.xml'))
    new_comps,new_nets,components=xml_data(WORK/(project+'-current.netlist.xml'))
    assert old_comps==new_comps,'Part/value/footprint change: '+project
    assert old_nets.keys()==new_nets.keys(),'Electrical pin group change: '+project
    human_mapping={old_nets[group]:new_nets[group] for group in old_nets}
    mapping={pcb_name(old):pcb_name(new) for old,new in human_mapping.items()}
    inverse={new:old for old,new in mapping.items()}
    assert len(mapping)==len(inverse),'Namespace collision'
    board=E/'kicad'/project/(project+'.kicad_pcb')
    original_board=WORK/'before'/project/(project+'.kicad_pcb')
    original=original_board.read_bytes().decode('utf-8')
    before=parse(original)
    inverse_aliases=dict(inverse)
    inverse_aliases.update({new:pcb_name(old) for old,new in human_mapping.items()})
    assert board_semantics(parse(board.read_bytes().decode()),inverse_aliases)==board_semantics(before,{}),'Live board has unrelated physical changes'
    touched=[]
    pattern=re.compile(r'(\((?:net|net_name)\s+(?:\d+\s+)?)"((?:\\.|[^"\\])*)"')
    def rename(match):
        name=match[2]
        if name in mapping and mapping[name]!=name:
            touched.append(name)
            return match[1]+'"'+mapping[name]+'"'
        return match[0]
    changed=pattern.sub(rename,original)
    linked=[]
    def relink(match):
        block=match[0]
        fp=parse(block.strip())
        ref=next(p[2] for p in find(fp,'property') if p[1]=='Reference')
        comp=components[ref]
        props={p.get('name'):p.get('value') for p in comp.findall('property')}
        metadata={'path':comp.find('sheetpath').get('tstamps')+comp.findtext('tstamps'),
                  'sheetname':props.get('Sheetname') or 'Root',
                  'sheetfile':props.get('Sheetfile') or project+'.kicad_sch'}
        for key,value in metadata.items():
            regex=re.compile(r'(?m)^(\t\t\('+key+r'\s+)"[^"]*"')
            block,count=regex.subn(lambda m:m[1]+'"'+value+'"',block)
            assert count==1,(project,ref,key,count)
        linked.append(ref)
        return block
    changed=re.sub(r'(?ms)^\t\(footprint .*?^\t\)\r?$',relink,changed)
    assert len(linked)==len(find(before,'footprint'))
    after=parse(changed)
    left=board_semantics(before,{})
    right=board_semantics(after,inverse)
    assert left==right,'PCB geometry or electrical groups changed: '+project
    before_hash=sha(original_board)
    board.write_bytes(changed.encode('utf-8'))
    pro=E/'kicad'/project/(project+'.kicad_pro')
    settings=json.loads((WORK/'before'/project/(project+'.kicad_pro')).read_text())
    old_settings=copy.deepcopy(settings)
    changed_patterns=[]
    for entry in settings.get('net_settings',{}).get('netclass_patterns',[]):
        old=entry['pattern']
        if old in mapping:
            entry['pattern']=mapping[old]
            if old!=entry['pattern']:changed_patterns.append({'old':old,**entry})
    restored=copy.deepcopy(settings)
    for entry in restored.get('net_settings',{}).get('netclass_patterns',[]):
        entry['pattern']=inverse.get(entry['pattern'],entry['pattern'])
    assert restored==old_settings,'Unexpected project rule change'
    if settings!=old_settings:pro.write_text(json.dumps(settings,indent=2)+'\n')
    reports[project]={
        'status':'PASS','netlist':'MATCH','components':len(old_comps),'net_groups':len(old_nets),
        'changed_net_names':{k:v for k,v in mapping.items() if k!=v},
        'renamed_pcb_net_names':sorted(set(touched)),
        'netclass_pattern_updates':changed_patterns,'relinked_footprints':len(linked),
        'board_sha256_before':before_hash,'board_sha256_after':sha(board),
        'geometry_and_electrical_groups':'PASS (full parsed PCB equality after inverse namespace mapping and removal of only footprint schematic-link metadata)',
        'canonical_geometry_sha256':hashlib.sha256(dump(left).encode()).hexdigest()
    }
    print(project,'MATCH',len(old_comps),'parts',len(old_nets),'groups',
          len(reports[project]['changed_net_names']),'explicit net renames; geometry PASS')
(WORK/'pcb_namespace_migration.json').write_text(json.dumps(reports,indent=2)+'\n')
