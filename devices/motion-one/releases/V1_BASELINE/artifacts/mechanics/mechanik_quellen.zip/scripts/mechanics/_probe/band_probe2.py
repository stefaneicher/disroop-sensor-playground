import sys, numpy as np, trimesh
sys.path.insert(0, "devices/motion-one/scripts/mechanics")
import build_enclosure as B
import cadquery as cq
P = B.P

def chk(name, s, tol=0.02):
    vs, ts = s.tessellate(tol, 0.1)
    m = trimesh.Trimesh([(v.x, v.y, v.z) for v in vs], ts, process=False); m.merge_vertices()
    u, c = np.unique(m.edges_sorted, axis=0, return_counts=True)
    print(name, "V=%.1f" % s.Volume(), "valid", s.isValid(), "open", int((c == 1).sum()), "nonman", int((c > 2).sum()), flush=True)
    return m

B.OUTER = B.outer_solid()
for kind in ("arc", "intersection"):
    B._PLAN_W0 = None
    w = B.plan_wire(3.85, 0.0, kind)
    bb = w.BoundingBox(); print(kind, "edges", len(w.Edges()), "x", bb.xmin, bb.xmax)
    s = cq.Solid.extrudeLinear(cq.Face.makeFromWires(w), cq.Vector(0, 0, 6.4)); chk("prism_" + kind, s)
w0 = B.plan_wire(0.0, 0.0)
print("w0 edges", [(round(e.startPoint().x,2), round(e.endPoint().x,2), e.geomType()) for e in w0.Edges()][:90])
w = B.plan_wire(3.85, 0.0)
print("w  edges", [(round(e.startPoint().x,2), round(e.endPoint().x,2), e.geomType()) for e in w.Edges()][:90])
