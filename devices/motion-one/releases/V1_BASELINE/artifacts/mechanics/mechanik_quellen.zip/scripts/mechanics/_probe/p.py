import cadquery as cq
s=cq.importers.importStep('/workspace/devices/motion-one/electronics/kicad/motion-one/export/motion-one-board.step').val()
for i,so in enumerate(s.Solids()):
    b=so.BoundingBox()
    if b.zmax>1.01: print(i,round(b.xmin,2),round(b.xmax,2),round(b.ymin,2),round(b.ymax,2),round(b.zmax,2))
