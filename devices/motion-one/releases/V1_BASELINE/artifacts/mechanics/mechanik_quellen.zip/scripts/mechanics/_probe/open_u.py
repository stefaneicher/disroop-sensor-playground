import numpy as np, trimesh, cadquery as cq
s=cq.Shape.importBrep("devices/motion-one/mechanics/cad/unterschale_glatt.brep")
vs,ts=s.tessellate(0.02,0.1)
m=trimesh.Trimesh([v.toTuple() for v in vs],ts,process=False); m.merge_vertices()
u,c=np.unique(m.edges_sorted,axis=0,return_counts=True)
for e in u[c==1][:12]:
    a,b=m.vertices[e]; print(a.round(2),b.round(2))
