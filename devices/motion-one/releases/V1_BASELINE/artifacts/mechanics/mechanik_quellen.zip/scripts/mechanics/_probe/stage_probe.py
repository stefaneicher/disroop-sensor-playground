"""Probe: STL-Dichtheit je Bauzustand (outer, inner, shell, shell+band, top-Rohling)."""
import sys, os, numpy as np, trimesh
sys.path.insert(0, "devices/motion-one/scripts/mechanics")
import build_enclosure as B
import cadquery as cq


def chk(name, s, tol=0.02):
    vs, ts = s.tessellate(tol, 0.1)
    m = trimesh.Trimesh([(v.x, v.y, v.z) for v in vs], ts, process=False); m.merge_vertices()
    u, c = np.unique(m.edges_sorted, axis=0, return_counts=True)
    bad = u[c != 2]
    xs = m.vertices[bad.ravel()].reshape(-1, 2, 3).mean(1)[:, 0] if len(bad) else []
    print(name, "V=%.1f" % s.Volume(), "valid", s.isValid(), "open", int((c == 1).sum()), "nonman", int((c > 2).sum()),
          "x-range", (round(float(min(xs)), 1), round(float(max(xs)), 1)) if len(xs) else None, flush=True)


B.OUTER = B.outer_solid(); chk("outer", B.OUTER)
inner = B.inner_solid(); chk("inner", inner)
shell = B.OUTER.cut(inner); chk("shell", shell)
jb = B.joint_band(); chk("band", jb)
shell2 = B.fuse_all(shell, [jb]); chk("shell+band", shell2)
top = shell2.intersect(B.box(-5, B.P.L + 5, -40, 40, B.P.Z_S, 40)); chk("top_rohling", top)
