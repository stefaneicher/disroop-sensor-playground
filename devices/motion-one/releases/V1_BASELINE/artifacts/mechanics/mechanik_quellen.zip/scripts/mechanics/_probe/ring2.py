import sys, numpy as np, trimesh
sys.path.insert(0, "devices/motion-one/scripts/mechanics")
import build_enclosure as B
P=B.P
def chk(n,s):
    vs,ts=s.tessellate(0.02,0.1)
    m=trimesh.Trimesh([(v.x,v.y,v.z) for v in vs],ts,process=False); m.merge_vertices()
    u,c=np.unique(m.edges_sorted,axis=0,return_counts=True)
    print(n,"V=%.1f"%s.Volume(),"open",int((c==1).sum()),"nonman",int((c>2).sum()),flush=True)
B.OUTER=B.outer_solid()
z0,z1=P.BAND_Z
for d0 in (1.0,1.013):
  for d1 in (3.85,3.863,3.9):
    r=B.plan_prism(d0,z0,z1).cut(B.plan_prism(d1,z0-0.1,z1+0.1)); chk(f"cut {d0} {d1}",r)
    chk(f"hole {d0} {d1}",B.plan_ring(d0,d1,z0,z1))
