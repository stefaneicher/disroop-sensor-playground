import cadquery as cq
s=cq.Shape.importBrep("devices/motion-one/mechanics/cad/oberschale.brep")
for f in s.Faces():
    bb=f.BoundingBox()
    if bb.xmin<=6.6 and bb.xmax>=6.4 and bb.xlen<1.0:
        print(f.geomType(),"x",round(bb.xmin,3),round(bb.xmax,3),"y",round(bb.ymin,2),round(bb.ymax,2),"z",round(bb.zmin,2),round(bb.zmax,2),"A",round(f.Area(),2))
