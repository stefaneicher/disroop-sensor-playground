import sys
sys.path.insert(0,"devices/motion-one/scripts/mechanics")
import build_enclosure as B
B.OUTER=B.outer_solid()
P=B.P
for off,z in ((0.95,-0.5),(2.65,-0.5),(0.95,-0.6),(1.0,-3.0),(3.85,-3.0),(0.0,0.0),(0.0,-0.5)):
    try: w=B.plan_wire(off,z); print(off,z,"ok",round(w.BoundingBox().zmin,4))
    except Exception as e: print(off,z,"ERR",e)
