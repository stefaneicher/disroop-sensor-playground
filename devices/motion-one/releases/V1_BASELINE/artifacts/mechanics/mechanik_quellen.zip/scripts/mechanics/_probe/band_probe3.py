import sys, numpy as np, trimesh
sys.path.insert(0, "devices/motion-one/scripts/mechanics")
import build_enclosure as B
import cadquery as cq
P = B.P
V = cq.Vector

def chk(name, s, tol=0.02):
    vs, ts = s.tessellate(tol, 0.1)
    m = trimesh.Trimesh([(v.x, v.y, v.z) for v in vs], ts, process=False); m.merge_vertices()
    u, c = np.unique(m.edges_sorted, axis=0, return_counts=True)
    bad = u[c > 2]
    xs = m.vertices[bad.ravel()].reshape(-1, 2, 3).mean(1)[:, 0] if len(bad) else [0]
    print(name, "V=%.1f" % s.Volume(), "valid", s.isValid(), "open", int((c == 1).sum()), "nonman", int((c > 2).sum()), "xmax_bad", round(float(max(xs)), 2), flush=True)

B.OUTER = B.outer_solid()
w0 = B.plan_wire(0.0, 0.0)
for name, offs in (("1step", [3.85]), ("steps", [1.0, 2.0, 3.0, 3.85]), ("fine", list(np.arange(0.5, 3.86, 0.5)) + [3.85])):
    w = w0
    prev = 0
    try:
        for o in offs:
            w = w.offset2D(-(o - prev), "arc")[0]; prev = o
        f = cq.Face.makeFromWires(w)
        chk(name, cq.Solid.extrudeLinear(f, V(0, 0, 6.4)))
        # trimmed alternative: face area check
        print(name, "area", f.Area(), "edges", len(w.Edges()))
    except Exception as e:
        print(name, "ERR", e)
