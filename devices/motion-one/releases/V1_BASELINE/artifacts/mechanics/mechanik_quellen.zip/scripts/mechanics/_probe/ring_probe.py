import sys, numpy as np, trimesh
sys.path.insert(0, "devices/motion-one/scripts/mechanics")
import build_enclosure as B
P=B.P
def chk(n,s):
    vs,ts=s.tessellate(0.02,0.1)
    m=trimesh.Trimesh([(v.x,v.y,v.z) for v in vs],ts,process=False); m.merge_vertices()
    u,c=np.unique(m.edges_sorted,axis=0,return_counts=True)
    print(n,"V=%.1f"%s.Volume(),"open",int((c==1).sum()),"nonman",int((c>2).sum()),flush=True)
B.OUTER=B.outer_solid()
chk("groove",B.groove()); chk("lip",B.lip().intersect(B.OUTER)); chk("shadow+",B.shadow_cutter(1)); chk("shadow-",B.shadow_cutter(-1))
chk("band",B.joint_band())
