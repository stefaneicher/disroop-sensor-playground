import cadquery as cq
s=cq.Shape.importBrep("devices/motion-one/mechanics/cad/unterschale_glatt.brep")
for f in s.Faces():
    b=f.BoundingBox()
    if b.xmax>20 and b.xmin<58 and b.zmax<0.1 and b.zmax>-1.5 and b.zmin>-16 and b.xlen<80:
        print(f.geomType(),[round(v,2) for v in (b.xmin,b.xmax,b.ymin,b.ymax,b.zmin,b.zmax)],round(f.Area(),3))
    for e in f.Edges():
        pass
