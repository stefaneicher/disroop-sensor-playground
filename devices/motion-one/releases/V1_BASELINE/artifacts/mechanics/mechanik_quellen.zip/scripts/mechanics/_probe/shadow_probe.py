import sys
exec(open("devices/motion-one/scripts/mechanics/_probe/ring3.py").read().split("r=B.plan_ring")[0])
def sw(off,z):
    p=B.plan_pts(off,400)
    e=cq.Edge.makeSpline([V(float(x),float(y),z) for x,y in p],periodic=True)
    return cq.Wire.assembleEdges([e])
def shadow2(sgn):
    s=P.SHADOW
    fr=cq.Solid.makeLoft([sw(s+0.01,-0.01*sgn),sw(0.0,s*sgn)] if sgn>0 else [sw(0.0,s*sgn),sw(s+0.01,-0.01*sgn)],ruled=True)
    za,zb=-0.005*sgn,(s-0.005)*sgn
    z0,z1=min(za,zb),max(za,zb)
    pr=cq.Solid.extrudeLinear(cq.Face.makeFromWires(sw(-3.0,0.0)),V(0,0,z1-z0)).translate(V(0,0,z0))
    return pr.cut(fr)
for sg in (1,-1):
    c1=B.shadow_cutter(sg); c2=shadow2(sg)
    chk(f"old{sg}",c1); chk(f"new{sg}",c2)
    base=B.OUTER.intersect(B.box(-5,175,-40,40,-3,3))
    for n,c in (("old",c1),("new",c2)):
        r=base.cut(c); chk(f"cut_{n}{sg}",r); print(r.isValid(),r.Volume())
