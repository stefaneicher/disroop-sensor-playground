import sys, numpy as np, trimesh
sys.path.insert(0, "devices/motion-one/scripts/mechanics")
import build_enclosure as B, cadquery as cq
P=B.P; V=cq.Vector
def chk(n,s,tol=0.02,ang=0.1):
    vs,ts=s.tessellate(tol,ang)
    m=trimesh.Trimesh([(v.x,v.y,v.z) for v in vs],ts,process=False); m.merge_vertices()
    u,c=np.unique(m.edges_sorted,axis=0,return_counts=True)
    bad=u[c>2]; x=m.vertices[bad.ravel()].reshape(-1,2,3).mean(1) if len(bad) else np.zeros((1,3))
    print(n,"nonman",int((c>2).sum()),"open",int((c==1).sum()),"x",x[:,0].min().round(2),x[:,0].max().round(2),"y",x[:,1].min().round(1),x[:,1].max().round(1),"z",x[:,2].min().round(1),x[:,2].max().round(1),flush=True)
B.OUTER=B.outer_solid()
r=B.plan_ring(1.0,3.85,-3.0,3.4)
chk("base",r); chk("fix",r.fix()); chk("clean",r.clean()); chk("tol.1",r,0.1,0.3); chk("tol.005",r,0.005,0.1)
f=cq.Face.makeFromWires(B.plan_wire(1.0,0.0),[B.plan_wire(3.85,0.0)]); chk("face",f)
