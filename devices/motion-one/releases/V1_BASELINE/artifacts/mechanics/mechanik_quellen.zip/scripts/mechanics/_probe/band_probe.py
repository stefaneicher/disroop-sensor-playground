import sys, numpy as np, trimesh
sys.path.insert(0, "devices/motion-one/scripts/mechanics")
import build_enclosure as B
import cadquery as cq
P = B.P

def chk(name, s, tol=0.02):
    vs, ts = s.tessellate(tol, 0.1)
    m = trimesh.Trimesh([(v.x, v.y, v.z) for v in vs], ts, process=False); m.merge_vertices()
    u, c = np.unique(m.edges_sorted, axis=0, return_counts=True)
    print(name, "V=%.1f" % s.Volume(), "valid", s.isValid(), "open", int((c == 1).sum()), "nonman", int((c > 2).sum()), flush=True)

B.OUTER = B.outer_solid()
d1 = P.LIP_D0 + P.LIP_W + P.GROOVE_CLR + P.BAND_T
print("d1", d1)
for off in (1.0, d1):
    w = B.plan_wire(off, 0.0)
    print("off", off, "edges", len(w.Edges()), "closed", w.IsClosed())
    chk(f"prism{off:.2f}", B.plan_prism(off, *P.BAND_Z))
ring = B.plan_ring(1.0, d1, *P.BAND_Z); chk("ring", ring)
chk("ring_inter", ring.intersect(B.OUTER))
for dd in (d1 + 0.03, d1 - 0.03):
    r = B.plan_ring(1.0, dd, *P.BAND_Z); chk(f"ring d1={dd:.2f}", r)
