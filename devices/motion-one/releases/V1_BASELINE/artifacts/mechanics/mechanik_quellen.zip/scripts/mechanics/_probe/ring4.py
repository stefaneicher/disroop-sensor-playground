import sys
sys.path.insert(0,"devices/motion-one/scripts/mechanics/_probe"); sys.argv=["x"]
exec(open("devices/motion-one/scripts/mechanics/_probe/ring3.py").read().split("r=B.plan_ring")[0])
def pw(off):
    p=B.plan_pts(off,400)
    e=cq.Edge.makeSpline([V(float(x),float(y),0) for x,y in p],periodic=True)
    return cq.Wire.assembleEdges([e])
for d0,d1 in ((1.0,3.85),):
    f=cq.Face.makeFromWires(pw(d0),[pw(d1)])
    s=cq.Solid.extrudeLinear(f,V(0,0,6.4)); chk("spline-ring",s); print(s.isValid(),s.Volume())
